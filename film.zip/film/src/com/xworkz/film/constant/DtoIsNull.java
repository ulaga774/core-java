package com.xworkz.film.constant;

import com.xworkz.film.dao.FilmDao;

public class DtoIsNull extends Exception {
	
	public DtoIsNull(String message) {
		super(message);
		
	}
	

}
