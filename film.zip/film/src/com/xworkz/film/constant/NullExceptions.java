package com.xworkz.film.constant;

public class NullExceptions extends Exception{
	
	public NullExceptions(String message) {
		super(message);
		
	}
	

}
